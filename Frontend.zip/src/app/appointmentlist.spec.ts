import { Appointmentlist } from './appointmentlist';

describe('Appointmentlist', () => {
  it('should create an instance', () => {
    expect(new Appointmentlist()).toBeTruthy();
  });
});
